<?php
session_start();


comprobarDatos();



function comprobarDatos(){

}

?>