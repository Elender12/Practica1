<?php
abstract class baseJuego{
    function comprobarTirada($eleccionOponente, $eleccionJugador, $res){}
}
?>